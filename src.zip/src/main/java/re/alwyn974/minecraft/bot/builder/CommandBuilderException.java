package re.alwyn974.minecraft.bot.builder;

public class CommandBuilderException extends Exception {

    public CommandBuilderException(String message) {
        super(message);
    }

}
